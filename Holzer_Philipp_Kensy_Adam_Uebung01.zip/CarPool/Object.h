///////////////////////////////////////////////////////////////////////////
// Workfile : Object.cpp
// Author : Philipp Holzer / Adam Kensy
// Date : 15.10.2019
// Description : common base class 
// Remarks : -
// Revision : 0
///////////////////////////////////////////////////////////////////////////

#ifndef OBJECT_H
#define OBJECT_H

class Object
{
protected:
	Object() = default;

public:

	virtual ~Object() = default;
};

#endif