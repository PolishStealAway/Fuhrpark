#ifndef PRINTPARAMETERS_H
#define PRINTPARAMETERS_H
#include <iostream>

std::string const cErrorMsg = "error write stream";
std::string const cErrAllocation = "could not allocate memory!";
size_t const cWidthTxt = 14;
size_t const cWidthKM = 7;


#endif